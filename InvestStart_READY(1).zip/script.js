const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:0}).format(n);

function calc(){
 let initial=Math.max(0,+$('initial').value||0), monthly=Math.max(0,+$('monthly').value||0);
 let years=Math.min(50,Math.max(1,+$('years').value||1)), rate=+$('rate').value||0;
 let m=years*12, mr=Math.pow(1+rate/100,1/12)-1, total=initial;
 for(let i=0;i<m;i++) total=total*(1+mr)+monthly;
 let contributed=initial+monthly*m, profit=total-contributed;
 $('total').textContent=money(total);$('contrib').textContent=money(contributed);
 $('profit').textContent=(profit>=0?'+':'')+money(profit);
 $('progress').style.width=Math.max(0,Math.min(100,contributed/Math.max(total,1)*100))+'%';
}
['initial','monthly','years','rate'].forEach(x=>$(x).addEventListener('input',calc));
$('calculate').addEventListener('click',calc);calc();

document.querySelector('.hamb').onclick=()=>document.querySelector('nav').classList.toggle('open');
document.querySelectorAll('nav a').forEach(a=>a.onclick=()=>document.querySelector('nav').classList.remove('open'));

const ids=['a','b','c','d'];
function mix(){
 let vals=ids.map(x=>+$(x).value);
 ids.forEach((x,i)=>$(x+'Val').textContent=vals[i]+'%');
 let sum=vals.reduce((a,b)=>a+b,0);$('sum').textContent=sum+'%';
 let acc=0, stops=[];
 const cols=['#6c5ce7','#45a3ff','#ff9d4d','#69c99a'];
 vals.forEach((v,i)=>{stops.push(cols[i]+' '+acc+'% '+(acc+v)+'%');acc+=v});
 $('donut').style.background='conic-gradient('+stops.join(',')+')';
}
ids.forEach(x=>$(x).addEventListener('input',mix));mix();
$('checkMix').onclick=()=>{
 let vals=ids.map(x=>+$(x).value),sum=vals.reduce((a,b)=>a+b,0),m=$('mixMessage');
 if(sum!==100){m.className='message bad';m.textContent='Сейчас распределено '+sum+'%. Для учебного портфеля доведи сумму до 100%.'}
 else if(Math.max(...vals)>=60){m.className='message bad';m.textContent='Большая доля одного направления. Это учебный пример риска концентрации.'}
 else {m.className='message good';m.textContent='Отлично! 100% распределено, и ни одна корзина не доминирует.'}
};

$('quizForm').onsubmit=e=>{
 e.preventDefault();let ans={q1:'b',q2:'b',q3:'a',q4:'a',q5:'a'},score=0;
 Object.entries(ans).forEach(([q,a])=>{if(document.querySelector('input[name='+q+']:checked')?.value===a)score++});
 let text=score===5?'🏆 Отлично! 5 из 5. Ты уверенно знаешь базовые принципы.':score>=3?'👍 Хорошо! База есть, но некоторые темы стоит повторить.':'📚 Ничего страшного — вернись к разделу обучения и попробуй снова.';
 $('quizResult').textContent='Результат: '+score+'/5. '+text;
};
